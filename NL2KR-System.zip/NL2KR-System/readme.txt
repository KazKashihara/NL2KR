Run an example of 7 sentences by:
- Run .\NL2KR-GUI.bat 7sentencesConfig
- Select NL2KR-L tab
- Make sure check box "New Lambda Impl." is checked
- Click "Run NL2KR-L"

